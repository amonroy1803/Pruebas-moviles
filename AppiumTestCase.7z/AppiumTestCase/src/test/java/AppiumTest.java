import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppiumTest {
	static AppiumDriver<MobileElement> driverAppium; 
	public static void main(String[] args) {
		openApp();
	}
		public static void openApp() {
			
			DesiredCapabilities cap = new DesiredCapabilities();
	        cap.setCapability("deviceName","Galaxy A10");
	        cap.setCapability("udid","R28M6095CNL");
	        cap.setCapability("platformName","Android");
	        cap.setCapability("platformVersion","9.0.0");
	        cap.setCapability("appPackage","com.sec.android.app.popupcalculator");
	        cap.setCapability("appActivity","com.sec.android.app.popupcalculator.Calculator");
	        driverAppium = new AppiumDriver<MobileElement>(cap);
	        //URL url = new URL("http://127.0.0.1:4723/wd/hub");
	        
	        driverAppium.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	        
	        System.out.println("iniciar automatizacion");
	        
	           
	        
	        MobileElement AcceptButton2 = driverAppium.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_01\r\n"));
	        AcceptButton2.click();
	        
	        MobileElement AcceptButton3 = driverAppium.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_02"));
	        AcceptButton3.click();
	        
	        MobileElement ButtonOp = driverAppium.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_add"));
	        ButtonOp.click();
	        
	        AcceptButton2.click();
	        AcceptButton3.click();
	        
	        MobileElement ButtonRes = driverAppium.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_equal\r\n"));
	        ButtonRes.click();
		}
	
 
}
